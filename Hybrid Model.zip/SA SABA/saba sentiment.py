import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import re
import nltk
from nltk.corpus import stopwords
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Model
from tensorflow.keras.layers import Input, Embedding, Conv1D, MaxPooling1D, LSTM, Dense, Dropout
from tensorflow.keras.optimizers import Adam
import pickle



# Load dataset
df = pd.read_csv('./amazon.csv')

# Display first few rows
print(df.head())

# Drop unnecessary columns (if any)
df = df[['reviewText', 'overall']]  # Assuming 'reviewText' and 'overall' are the relevant columns

# Drop missing values
df.dropna(inplace=True)

# Convert ratings to binary sentiment (1 = positive, 0 = negative)
df['sentiment'] = df['overall'].apply(lambda x: 1 if x >= 4 else 0)

# Preprocess text
nltk.download('stopwords')
nltk.download('punkt')  # Download the punkt tokenizer models
stop_words = set(stopwords.words('english'))

def preprocess_text(text):
    text = re.sub(r'[^a-zA-Z\s]', '', text, re.I | re.A)
    text = text.lower()
    text = text.strip()
    tokens = nltk.word_tokenize(text)
    filtered_tokens = [token for token in tokens if token not in stop_words]
    return ' '.join(filtered_tokens)

df['processed_review'] = df['reviewText'].apply(preprocess_text)

# Tokenize and pad sequences
max_words = 10000
max_len = 100

tokenizer = Tokenizer(num_words=max_words)
tokenizer.fit_on_texts(df['processed_review'])
sequences = tokenizer.texts_to_sequences(df['processed_review'])
padded_sequences = pad_sequences(sequences, maxlen=max_len)



# Save the tokenizer to a file
with open('C:/Users/fahad/OneDrive/Desktop/SA SABA/tokenizer.pickle', 'wb') as handle:
    pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)

# Encode labels
le = LabelEncoder()
labels = le.fit_transform(df['sentiment'])

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(padded_sequences, labels, test_size=0.2, random_state=42)

# Check shapes
print(f'X_train shape: {X_train.shape}')
print(f'X_test shape: {X_test.shape}')
print(f'y_train shape: {y_train.shape}')
print(f'y_test shape: {y_test.shape}')

# Model parameters
embedding_dim = 100
filters = 128
kernel_size = 5
lstm_units = 100

# Build model
input_layer = Input(shape=(max_len,))
embedding_layer = Embedding(max_words, embedding_dim, input_length=max_len)(input_layer)

# CNN layer
cnn_layer = Conv1D(filters, kernel_size, activation='relu')(embedding_layer)
cnn_layer = MaxPooling1D(pool_size=2)(cnn_layer)

# LSTM layer
lstm_layer = LSTM(lstm_units)(cnn_layer)

# Fully connected layers
dense_layer = Dense(128, activation='relu')(lstm_layer)
dropout_layer = Dropout(0.5)(dense_layer)
output_layer = Dense(1, activation='sigmoid')(dropout_layer)

# Compile model
model = Model(inputs=input_layer, outputs=output_layer)
model.compile(loss='binary_crossentropy', optimizer=Adam(learning_rate=0.001), metrics=['accuracy'])
model.save('C:/Users/fahad/OneDrive/Desktop/SA SABA/model.keras')

# Model summary
model.summary()

# Train model
history = model.fit(X_train, y_train, epochs=5, batch_size=128, validation_split=0.2)

# Plot training history
plt.figure(figsize=(12, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['loss'], label='train_loss')
plt.plot(history.history['val_loss'], label='val_loss')
plt.title('Training and Validation Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['accuracy'], label='train_accuracy')
plt.plot(history.history['val_accuracy'], label='val_accuracy')
plt.title('Training and Validation Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()
plt.show()

# Evaluate model
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print(f'Test Loss: {test_loss}')
print(f'Test Accuracy: {test_accuracy}')

# Predict on test set
y_pred = (model.predict(X_test) > 0.5).astype("int32")

# Classification report
from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred, target_names=['Negative', 'Positive']))

# Confusion matrix
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=['Negative', 'Positive'], yticklabels=['Negative', 'Positive'])
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.title('Confusion Matrix')
plt.show()
